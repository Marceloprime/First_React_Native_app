import React from 'react'
import {Text} from 'react-native'
import Padrao from '../estilo/Padrao'

export default function(){
    return(<Text style={[Padrao.ex]}>Simples</Text>)
}
